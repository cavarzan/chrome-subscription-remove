setInterval(function () {
    fecha_modal();
} , 2000);


setInterval(function () {
    fecha_modal();
} , 4000);